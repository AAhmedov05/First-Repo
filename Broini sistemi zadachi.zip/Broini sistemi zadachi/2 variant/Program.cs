﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_variant
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 0x017F;//16naysetichno chislo
            string dve = Convert.ToString(x, 2);//Prevristame v dvoichno
            Console.WriteLine(dve);//izvejdame dvoichnoto


        }
    }
}
