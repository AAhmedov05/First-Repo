﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Broini_sistemi_zadachi
{
    class Program
    {
        static void Main(string[] args)
        {
            string x = Console.ReadLine();//vivejdame 16naysetichno
            int des = Convert.ToInt32(x,16);//Prevrishtame seshnaysetichnoto v desetichno
            string dve = Convert.ToString(des,2);//desetichnoto prevrishtame v dvoichno
            Console.WriteLine(dve);//izvejdame dvoichnoto chislo
        }
    }
}
