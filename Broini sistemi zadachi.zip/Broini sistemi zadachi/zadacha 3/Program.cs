﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadacha_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string dve=Console.ReadLine();//Vivejdame dvoichno chislo
            int ten = Convert.ToInt32(dve,2);//Preobrazuvame go v desetichno
            string shesnaysetichno = Convert.ToString(ten,16).ToUpper();//Preobrazuvame ot desetichno v seshnaysetichno i zaradi T
            Console.WriteLine(shesnaysetichno);//Izvejdam

        }
    }
}
