﻿using MyPhoneProject.Controller;
using MyPhoneProject.Model;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.View
{
    public class Display
    {
        private PhoneController controller;
        private PhoneContext context;
        private int exit=6;
        private void SeeSmartPhones() 
        {
            var products = controller.GetSmartPhones();
            foreach (var item in products)
            {
                Console.WriteLine($"{item.Id} {item.Brand_Name} {item.Model} {item.Operation_System} {item.Processor_Id} {item.Battery_Id} {item.Camera_Id} {item.Screen_Id}" +
                    $"{item.Release_Date} {item.Picture}");
            }
        
        }

        private void ShowMenu() 
        {
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Update");
            Console.WriteLine("3. Delete");
            Console.WriteLine("4. SeeAll");
            Console.WriteLine("6. Exit");
        }
        private void MainMenu() 
        {
            int command = int.Parse(Console.ReadLine());
        }
        private void AddSmartPhone() 
        {
            SmartPhone phone = new SmartPhone();
            context = new PhoneContext();
            Console.WriteLine("Write brand name:");
            phone.Brand_Name = Console.ReadLine();
            Console.WriteLine("Write model:");
            phone.Model = Console.ReadLine();
            Console.WriteLine("Write operation system:");
            phone.Operation_System = Console.ReadLine();
            Console.WriteLine("Write some date(it can be null!!!)");
            int[] date = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            phone.Release_Date = new DateTime(date[0],date[1],date[2]);
            Console.WriteLine("Write Imei:");
            phone.Imei = char.Parse(Console.ReadLine());
            Console.WriteLine("Upload some picture(can be empty!!!)");
            phone.Picture = Console.ReadLine().Split(' ').Select(byte.Parse).ToArray();
            context.SaveChanges();
        }

        private void UpdateSmartPhone() 
        {
            context = new PhoneContext();
            Console.WriteLine("Enter ID:");
            int id = int.Parse(Console.ReadLine());
            SmartPhone phone = context.SmartPhones.Find();
            if (phone!=null)
            {
                Console.WriteLine("Write brand name:");
                phone.Brand_Name = Console.ReadLine();
                Console.WriteLine("Write model:");
                phone.Model = Console.ReadLine();
                Console.WriteLine("Write operation system:");
                phone.Operation_System = Console.ReadLine();
                Console.WriteLine("Write some date(it can be null!!!)");
                int[] date = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
                phone.Release_Date = new DateTime(date[0], date[1], date[2]);
                Console.WriteLine("Write Imei:");
                phone.Imei = char.Parse(Console.ReadLine());
                Console.WriteLine("Upload some picture(can be empty!!!)");
                phone.Picture = Console.ReadLine().Split(' ').Select(byte.Parse).ToArray();
                controller.UpdateSmartPhone(phone);
            }
            else
            {
                Console.WriteLine("SmartPhone is not available!!!");
            }
        }
        private void DropSmartPhone() 
        {
            Console.WriteLine("Enter Id:");
            int id = int.Parse(Console.ReadLine());
            controller.DeleteSmartPhone(id);
            Console.WriteLine("Done.");
        }
    }
}
