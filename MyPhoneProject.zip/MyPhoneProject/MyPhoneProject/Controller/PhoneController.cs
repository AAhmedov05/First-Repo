﻿using MyPhoneProject.Model;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.Controller
{
    public class PhoneController
    {
        private PhoneContext context;
        private PhoneController controller;

        public List<SmartPhone> GetSmartPhones() 
        {
            using (context = new PhoneContext())
            {
                return context.SmartPhones.ToList();
            }
        }

        public void AddSmartPhone(SmartPhone phone) 
        {
            using (context = new PhoneContext())
            {
                context.SmartPhones.Add(phone);
                context.SaveChanges();
            }
        }

        public void UpdateSmartPhone(SmartPhone phone) 
        {
            using (context = new PhoneContext())
            {
                var item = context.SmartPhones.Find(phone.Id);
                if (item != null) 
                {
                    context.Entry(item).CurrentValues.SetValues(phone);
                    context.SaveChanges();
                }
            }
        }

        public void DeleteSmartPhone(int id) 
        {
            using (context=new PhoneContext())
            {
                var item = context.SmartPhones.Find(id);
                if (item!=null)
                {
                    context.SmartPhones.Remove(item);
                    context.SaveChanges();
                }
            }
        }
    }
}
