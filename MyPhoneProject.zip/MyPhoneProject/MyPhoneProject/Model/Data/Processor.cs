﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.Model.Data
{
    public class Processor
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        public double Frequance { get; set; }
        public int Ram { get; set; }
    }
}
