﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyPhoneProject.Model.Data
{
    public class SmartPhone
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public string Brand_Name { get; set; }
        public string Model { get; set; }
        public string Operation_System { get; set; }
       
        //[ForeignKey(nameof(Processor))]
        public Processor Processor_Id { get; set; }
        
        //[ForeignKey(nameof(Battery))]
        public Battery Battery_Id { get; set; }
        
        //[ForeignKey(nameof(Camera))]
        public Camera Camera_Id { get; set; }
        
        //[ForeignKey(nameof(Screen))]
        public Screen Screen_Id { get; set; }
        public DateTime? Release_Date { get; set; }
        public char Imei { get; set; }
        public byte[] Picture { get; set; }
    }
}
