﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.Model.Data
{
    public class Screen
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public double Screen_Size { get; set; }
        public string Display_Resolution { get; set; }
        public int Refresh_Rate { get; set; }
        public string Display_Type { get; set; }
    }
}
