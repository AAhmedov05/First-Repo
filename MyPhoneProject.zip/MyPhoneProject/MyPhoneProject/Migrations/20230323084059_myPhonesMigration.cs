﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MyPhoneProject.Migrations
{
    public partial class myPhonesMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Batteries",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Battery_Type = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Battery_Capacity = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Batteries", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Cameras",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Front_Camera = table.Column<int>(type: "int", nullable: false),
                    Rear_Camera = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cameras", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Processors",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Frequance = table.Column<double>(type: "float", nullable: false),
                    Ram = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Processors", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Screens",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Screen_Size = table.Column<double>(type: "float", nullable: false),
                    Display_Resolution = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Refresh_Rate = table.Column<int>(type: "int", nullable: false),
                    Display_Type = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Screens", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SmartPhones",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Brand_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Model = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Operation_System = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Processor_IdId = table.Column<int>(type: "int", nullable: true),
                    Battery_IdId = table.Column<int>(type: "int", nullable: true),
                    Camera_IdId = table.Column<int>(type: "int", nullable: true),
                    Screen_IdId = table.Column<int>(type: "int", nullable: true),
                    Release_Date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Imei = table.Column<string>(type: "nvarchar(1)", nullable: false),
                    Picture = table.Column<byte[]>(type: "varbinary(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SmartPhones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SmartPhones_Batteries_Battery_IdId",
                        column: x => x.Battery_IdId,
                        principalTable: "Batteries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SmartPhones_Cameras_Camera_IdId",
                        column: x => x.Camera_IdId,
                        principalTable: "Cameras",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SmartPhones_Processors_Processor_IdId",
                        column: x => x.Processor_IdId,
                        principalTable: "Processors",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SmartPhones_Screens_Screen_IdId",
                        column: x => x.Screen_IdId,
                        principalTable: "Screens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SmartPhones_Battery_IdId",
                table: "SmartPhones",
                column: "Battery_IdId");

            migrationBuilder.CreateIndex(
                name: "IX_SmartPhones_Camera_IdId",
                table: "SmartPhones",
                column: "Camera_IdId");

            migrationBuilder.CreateIndex(
                name: "IX_SmartPhones_Processor_IdId",
                table: "SmartPhones",
                column: "Processor_IdId");

            migrationBuilder.CreateIndex(
                name: "IX_SmartPhones_Screen_IdId",
                table: "SmartPhones",
                column: "Screen_IdId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SmartPhones");

            migrationBuilder.DropTable(
                name: "Batteries");

            migrationBuilder.DropTable(
                name: "Cameras");

            migrationBuilder.DropTable(
                name: "Processors");

            migrationBuilder.DropTable(
                name: "Screens");
        }
    }
}
