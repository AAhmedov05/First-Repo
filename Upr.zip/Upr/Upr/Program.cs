﻿using MiniCompany.Model;
using System;
using MiniCompany.Views;

namespace MiniCompany
{
    class Program
    {
        static void Main(string[] args)
        {
            Displays displays = new Displays();
        }
    }
}
