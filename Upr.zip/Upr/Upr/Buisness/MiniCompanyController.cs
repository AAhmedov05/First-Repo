﻿using MiniCompany.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniCompany.Buisness
{
    public class MiniCompanyController
    {
        
        public void AddDepartment(Department department) 
        {
            MiniCompanyContext context = new MiniCompanyContext();
            context.Departments.Add(department);
            context.SaveChanges();
        }
        public void DeleteDepartment(int id)
        {
            MiniCompanyContext context = new MiniCompanyContext();
            var department = context.Departments.Find(id);
            if (department!=null)
            {
                context.Departments.Remove(department);
                context.SaveChanges();
            }
        }

        public void UpdateDepartment(Department department) 
        {
            MiniCompanyContext context = new MiniCompanyContext();
            var item = context.Departments.Find(department.Id);
            if (item!=null) 
            {
                context.Entry(item).CurrentValues.SetValues(department);
                context.SaveChanges();
            }
        }

        public List<Department> GetAll() 
        {
            MiniCompanyContext context = new MiniCompanyContext();
            return context.Departments.ToList();
        }
    }
}
