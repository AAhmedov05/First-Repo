﻿using MiniCompany.Buisness;
using MiniCompany.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniCompany.Views
{
    class Displays
    {
        private int closed = 5;
        private MiniCompanyController controller = new MiniCompanyController();
        private MiniCompanyContext context = new MiniCompanyContext();
        private Department department= new Department();

        public Displays()
        {
            Input();
        }
        public void Menu() 
        {
            Console.WriteLine($"{new string('-', 18)}Hello!{new string('-',18)}");
            Console.WriteLine($"1. Add Department");
            Console.WriteLine($"2. Update Department(You cannot update empty!!)");
            Console.WriteLine($"3. Delete Department");
            Console.WriteLine($"4. List All of the Departments");
            Console.WriteLine($"5. End");
            Console.WriteLine($"{new string('-', 36)}");
        }

        public void Input() 
        {
            int command = -1;
            do
            {
                Menu();
                command = int.Parse(Console.ReadLine());
                switch (command)
                {
                    case 1:
                        Add();
                        break;
                    case 2:
                        Update();
                        break;
                    case 3:
                        Delete();
                        break;
                    case 4:
                        ListAll();
                        break;
                    default:
                        break;
                }
            } while (command != closed);
        }

        public void Add() 
        {
            Console.WriteLine("Enter department name:");
            department = new Department();
            department.Name = Console.ReadLine();
            controller.AddDepartment(department);
        }

        public void Update() 
        {
            Console.WriteLine("Enter ID to update department:");
            int id = int.Parse(Console.ReadLine());
            department = context.Departments.Find(id);
            if (department!=null) 
            {
                Console.WriteLine("Enter new department name:");
                department.Name = Console.ReadLine();
                controller.UpdateDepartment(department);
            }
            else
            {
                Console.WriteLine("The department cannot found!!!");
            }
        }

        public void Delete() 
        {
            Console.WriteLine("Enter ID to delete department:");
            int id = int.Parse(Console.ReadLine());
            controller.DeleteDepartment(id);
        }

        public void ListAll() 
        {
            var departments = controller.GetAll();
            Console.WriteLine($"{new string(' ', 1)}Departments{new string(' ', 5)}");
            Console.WriteLine($"Id{new string(' ',5)}Name");
            foreach (var item in departments)
            {
                Console.WriteLine($"{item.Id}{new string(' ',5)}{item.Name}");
            }
        }
    }
}
