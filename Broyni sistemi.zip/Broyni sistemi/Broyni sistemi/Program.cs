﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Broyni_sistemi
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = int.Parse(Console.ReadLine());
            string y = Convert.ToString(x,2);
            Console.WriteLine(x);
            Console.WriteLine(y);

        }
    }
}
