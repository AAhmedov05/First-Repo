﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string x = Console.ReadLine();
            string y = Console.ReadLine();
            int x10 = Convert.ToInt32(x,2);
            int y10 = Convert.ToInt32(y,2);
            int result = x10 + y10;
            string result1 = Convert.ToString(result,2);
            Console.WriteLine(result1);



        }
    }
}
