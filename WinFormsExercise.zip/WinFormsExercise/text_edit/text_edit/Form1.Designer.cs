﻿
namespace text_edit
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pole = new System.Windows.Forms.RichTextBox();
            this.comboBoxFont = new System.Windows.Forms.ComboBox();
            this.buttonBold = new System.Windows.Forms.Button();
            this.buttonItalic = new System.Windows.Forms.Button();
            this.buttonUnderline = new System.Windows.Forms.Button();
            this.buttonBlack = new System.Windows.Forms.Button();
            this.buttonIndigo = new System.Windows.Forms.Button();
            this.buttonDarkGreen = new System.Windows.Forms.Button();
            this.buttonDarkRed = new System.Windows.Forms.Button();
            this.buttonDarkBlue = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pole
            // 
            this.pole.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pole.Location = new System.Drawing.Point(2, 40);
            this.pole.Name = "pole";
            this.pole.Size = new System.Drawing.Size(730, 420);
            this.pole.TabIndex = 0;
            this.pole.Text = "";
            // 
            // comboBoxFont
            // 
            this.comboBoxFont.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.comboBoxFont.FormattingEnabled = true;
            this.comboBoxFont.Items.AddRange(new object[] {
            "Arial",
            "Jokerman",
            "Microsoft Sans Serif",
            "Tahoma"});
            this.comboBoxFont.Location = new System.Drawing.Point(4, 5);
            this.comboBoxFont.Name = "comboBoxFont";
            this.comboBoxFont.Size = new System.Drawing.Size(130, 28);
            this.comboBoxFont.TabIndex = 1;
            // 
            // buttonBold
            // 
            this.buttonBold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonBold.Location = new System.Drawing.Point(140, 5);
            this.buttonBold.Name = "buttonBold";
            this.buttonBold.Size = new System.Drawing.Size(30, 30);
            this.buttonBold.TabIndex = 2;
            this.buttonBold.Text = "B";
            this.buttonBold.UseVisualStyleBackColor = true;
            // 
            // buttonItalic
            // 
            this.buttonItalic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.buttonItalic.Location = new System.Drawing.Point(170, 5);
            this.buttonItalic.Name = "buttonItalic";
            this.buttonItalic.Size = new System.Drawing.Size(30, 30);
            this.buttonItalic.TabIndex = 3;
            this.buttonItalic.Text = "I";
            this.buttonItalic.UseVisualStyleBackColor = true;
            // 
            // buttonUnderline
            // 
            this.buttonUnderline.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            this.buttonUnderline.Location = new System.Drawing.Point(200, 5);
            this.buttonUnderline.Name = "buttonUnderline";
            this.buttonUnderline.Size = new System.Drawing.Size(30, 30);
            this.buttonUnderline.TabIndex = 4;
            this.buttonUnderline.Text = "U";
            this.buttonUnderline.UseVisualStyleBackColor = true;
            // 
            // buttonBlack
            // 
            this.buttonBlack.BackColor = System.Drawing.SystemColors.WindowText;
            this.buttonBlack.Location = new System.Drawing.Point(355, 5);
            this.buttonBlack.Name = "buttonBlack";
            this.buttonBlack.Size = new System.Drawing.Size(30, 30);
            this.buttonBlack.TabIndex = 5;
            this.buttonBlack.UseVisualStyleBackColor = false;
            // 
            // buttonIndigo
            // 
            this.buttonIndigo.BackColor = System.Drawing.Color.Indigo;
            this.buttonIndigo.Location = new System.Drawing.Point(385, 5);
            this.buttonIndigo.Name = "buttonIndigo";
            this.buttonIndigo.Size = new System.Drawing.Size(30, 30);
            this.buttonIndigo.TabIndex = 6;
            this.buttonIndigo.UseVisualStyleBackColor = false;
            // 
            // buttonDarkGreen
            // 
            this.buttonDarkGreen.BackColor = System.Drawing.Color.DarkGreen;
            this.buttonDarkGreen.Location = new System.Drawing.Point(415, 5);
            this.buttonDarkGreen.Name = "buttonDarkGreen";
            this.buttonDarkGreen.Size = new System.Drawing.Size(30, 30);
            this.buttonDarkGreen.TabIndex = 7;
            this.buttonDarkGreen.UseVisualStyleBackColor = false;
            // 
            // buttonDarkRed
            // 
            this.buttonDarkRed.BackColor = System.Drawing.Color.DarkRed;
            this.buttonDarkRed.Location = new System.Drawing.Point(445, 5);
            this.buttonDarkRed.Name = "buttonDarkRed";
            this.buttonDarkRed.Size = new System.Drawing.Size(30, 30);
            this.buttonDarkRed.TabIndex = 8;
            this.buttonDarkRed.UseVisualStyleBackColor = false;
            // 
            // buttonDarkBlue
            // 
            this.buttonDarkBlue.BackColor = System.Drawing.Color.DarkBlue;
            this.buttonDarkBlue.Location = new System.Drawing.Point(475, 5);
            this.buttonDarkBlue.Name = "buttonDarkBlue";
            this.buttonDarkBlue.Size = new System.Drawing.Size(30, 30);
            this.buttonDarkBlue.TabIndex = 9;
            this.buttonDarkBlue.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 461);
            this.Controls.Add(this.buttonDarkBlue);
            this.Controls.Add(this.buttonDarkRed);
            this.Controls.Add(this.buttonDarkGreen);
            this.Controls.Add(this.buttonIndigo);
            this.Controls.Add(this.buttonBlack);
            this.Controls.Add(this.buttonUnderline);
            this.Controls.Add(this.buttonItalic);
            this.Controls.Add(this.buttonBold);
            this.Controls.Add(this.comboBoxFont);
            this.Controls.Add(this.pole);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Опростен текстов редактор";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox pole;
        private System.Windows.Forms.ComboBox comboBoxFont;
        private System.Windows.Forms.Button buttonBold;
        private System.Windows.Forms.Button buttonItalic;
        private System.Windows.Forms.Button buttonUnderline;
        private System.Windows.Forms.Button buttonBlack;
        private System.Windows.Forms.Button buttonIndigo;
        private System.Windows.Forms.Button buttonDarkGreen;
        private System.Windows.Forms.Button buttonDarkRed;
        private System.Windows.Forms.Button buttonDarkBlue;
    }
}

