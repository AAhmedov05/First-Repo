﻿using System;

namespace TryCatchExercises
{
    class Program
    {
        static void Main(string[] args)
        {

            //
            //Person person2 = new Person(string.Empty, "Goshev", 31);
            //Person person3 = new Person("Ivan", null, 63);
            //Person person4 = new Person("Stoyan", "Kolev", -1);
            //Person person5 = new Person("Iskren", "Ivanov", 121);

            try
            {
                Person person1 = new Person("Pesho", "Peshev", 24);
            }
            catch (ArgumentNullException e)
            {
                Console.WriteLine($"Exception throw:{e.Message}");
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.WriteLine($"Exception throw:{e.Message}");
            }
        }
    }
}
