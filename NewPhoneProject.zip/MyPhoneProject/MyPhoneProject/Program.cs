﻿using MyPhoneProject.View;
using System;

namespace MyPhoneProject
{
    public class Program
    {
        static void Main(string[] args)
        {
            Display display = new Display();
        }
    }
}
