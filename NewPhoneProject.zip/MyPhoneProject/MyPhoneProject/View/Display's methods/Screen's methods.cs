﻿using MyPhoneProject.Controller;
using MyPhoneProject.Interfaces;
using MyPhoneProject.Model;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.View.Display_s_methods
{
    public class Screen_s_methods : IMethods
    {
        private PhoneController controller;

        public void Add()
        {
            Screen screen = new Screen();
            controller = new PhoneController();

            Console.WriteLine("Write screen size:");
            screen.Screen_Size = double.Parse(Console.ReadLine());

            Console.WriteLine("Write display resolution:");
            screen.Display_Resolution = Console.ReadLine();

            Console.WriteLine("Enter refresh rate");
            screen.Refresh_Rate = int.Parse(Console.ReadLine());

            Console.WriteLine("Write display type:");
            screen.Display_Type = Console.ReadLine();

            controller.screenController.Add(screen);
        }

        public void Delete()
        {
            controller = new PhoneController();

            Console.WriteLine("Enter Id:");
            int id = int.Parse(Console.ReadLine());
            controller.screenController.Delete(id);
            Console.WriteLine("Done.");
        }

        public void SeeAll()
        {
            controller = new PhoneController();

            Console.WriteLine(new string('-', 40));
            var products = controller.screenController.GetAll();
            Console.WriteLine($"{"Id"} {"Size"} {"Resolution"} {"Refresh_Rate"} {"Type"}");
            foreach (var item in products)
            {
                Console.WriteLine($"{item.Id,-2} {item.Screen_Size,-3} {item.Display_Resolution,-9} {item.Refresh_Rate,4} {item.Display_Type,12}");
            }
            Console.WriteLine(new string('-', 40));
        }

        public void Update()
        { 
            controller = new PhoneController();
            
            Console.WriteLine("Enter ID:");
            int id = int.Parse(Console.ReadLine());
            Screen screen = controller.screenController.GetId(id);

            if (screen != null)
            {
                controller = new PhoneController();

                Console.WriteLine("Write screen size:");
                screen.Screen_Size = double.Parse(Console.ReadLine());

                Console.WriteLine("Write display resolution:");
                screen.Display_Resolution = Console.ReadLine();

                Console.WriteLine("Enter refresh rate");
                screen.Refresh_Rate = int.Parse(Console.ReadLine());

                Console.WriteLine("Write display type:");
                screen.Display_Type = Console.ReadLine();

                controller.screenController.Update(screen);
            }
            else
            {
                Console.WriteLine("Screen is not available!!!");
            }
        }
    }
}
