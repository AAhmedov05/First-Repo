﻿using MyPhoneProject.Controller;
using MyPhoneProject.Interfaces;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.View.Display_s_methods
{
    public class SmartPhone_s_methods : IMethods
    {
        private PhoneController controller;

        public void Add()
        {
            SmartPhone phone = new SmartPhone();
            controller = new PhoneController();

            Console.WriteLine("Write brand name:");
            phone.Brand_Name = Console.ReadLine();
            Console.WriteLine("Write model:");
            phone.Model = Console.ReadLine();
            Console.WriteLine("Write operation system:");
            phone.Operation_System = Console.ReadLine();
            Console.WriteLine("Write processor_id:");
            phone.Processor_Id = int.Parse(Console.ReadLine());           
            Console.WriteLine("Write battery_id:");
            phone.Battery_Id = int.Parse(Console.ReadLine());           
            Console.WriteLine("Write screen_id:");
            phone.Screen_Id = int.Parse(Console.ReadLine());
            Console.WriteLine("Write camera_id:");
            phone.Camera_Id = int.Parse(Console.ReadLine());
            Console.WriteLine("Write some date(it can be null!!!)");
            int[] date = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            phone.Release_Date = new DateTime(date[0], date[1], date[2]);
            Console.WriteLine("Write Imei:");
            phone.Imei = char.Parse(Console.ReadLine());
            Console.WriteLine("Upload some picture(can be empty!!!)");
            phone.Picture = Console.ReadLine().Split(' ').Select(byte.Parse).ToArray();

            controller.smartPhoneController.Add(phone);

        }

        public void Delete()
        {
            controller = new PhoneController();

            Console.WriteLine("Enter Id:");
            int id = int.Parse(Console.ReadLine());
            controller.smartPhoneController.Delete(id);
            Console.WriteLine("Done.");
        }

        public void SeeAll()
        {
            controller = new PhoneController();

            var products = controller.smartPhoneController.GetAll();
            Console.WriteLine(new string('-',80));
            Console.WriteLine($"{"Id",-2} {"Brand",-8} {"Model",3} {"OS",4}  {"CPU_Id"} {"Battery_Id"} {"Camera_Id"} {"Screen_Id"} {"Release_Date"}" );//{"Image"}
            foreach (var item in products)
            {
                Console.WriteLine($"{item.Id,-2} {item.Brand_Name,-8} {item.Model,-9} {item.Operation_System,4} {item.Processor_Id,4} {item.Battery_Id,6} {item.Camera_Id,10} {item.Screen_Id,10}" +
                    $"     {item.Release_Date,-5:MM/dd/yyyy}"); /*{item.Picture}*/
            }
            Console.WriteLine(new string('-', 80));
        }

        public void Update()
        {
            controller = new PhoneController();

            Console.WriteLine("Enter ID:");
            int id = int.Parse(Console.ReadLine());
            SmartPhone phone = controller.smartPhoneController.GetId(id);
            if (phone != null)
            {
                Console.WriteLine("Write brand name:");
                phone.Brand_Name = Console.ReadLine();
                Console.WriteLine("Write model:");
                phone.Model = Console.ReadLine();
                Console.WriteLine("Write operation system:");
                phone.Operation_System = Console.ReadLine();
                Console.WriteLine("Write some date(it can be null!!!)");
                int[] date = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
                phone.Release_Date = new DateTime(date[0], date[1], date[2]);
                Console.WriteLine("Write Imei:");
                phone.Imei = char.Parse(Console.ReadLine());
                Console.WriteLine("Upload some picture(can be empty!!!)");
                phone.Picture = Console.ReadLine().Split(' ').Select(byte.Parse).ToArray();
                controller.smartPhoneController.Update(phone);
            }
            else
            {
                Console.WriteLine("SmartPhone is not available!!!");
            }
        }
    }
}
