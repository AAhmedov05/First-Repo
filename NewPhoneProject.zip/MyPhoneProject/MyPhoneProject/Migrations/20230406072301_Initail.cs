﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MyPhoneProject.Migrations
{
    public partial class Initail : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Batteries",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Battery_Type = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Battery_Capacity = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Batteries", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Cameras",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Front_Camera = table.Column<int>(type: "int", nullable: false),
                    Rear_Camera = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cameras", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Processors",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Frequance = table.Column<double>(type: "float", nullable: false),
                    Ram = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Processors", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Screens",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Screen_Size = table.Column<double>(type: "float", nullable: false),
                    Display_Resolution = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Refresh_Rate = table.Column<int>(type: "int", nullable: false),
                    Display_Type = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Screens", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SmartPhones",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Brand_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Model = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Operation_System = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Processor_Id = table.Column<int>(type: "int", nullable: false),
                    Battery_Id = table.Column<int>(type: "int", nullable: false),
                    Camera_Id = table.Column<int>(type: "int", nullable: false),
                    Screen_Id = table.Column<int>(type: "int", nullable: false),
                    Release_Date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Imei = table.Column<string>(type: "nvarchar(1)", nullable: false),
                    Picture = table.Column<byte[]>(type: "varbinary(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SmartPhones", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SmartPhones_Batteries_Battery_Id",
                        column: x => x.Battery_Id,
                        principalTable: "Batteries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SmartPhones_Cameras_Camera_Id",
                        column: x => x.Camera_Id,
                        principalTable: "Cameras",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SmartPhones_Processors_Processor_Id",
                        column: x => x.Processor_Id,
                        principalTable: "Processors",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SmartPhones_Screens_Screen_Id",
                        column: x => x.Screen_Id,
                        principalTable: "Screens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SmartPhones_Battery_Id",
                table: "SmartPhones",
                column: "Battery_Id");

            migrationBuilder.CreateIndex(
                name: "IX_SmartPhones_Camera_Id",
                table: "SmartPhones",
                column: "Camera_Id");

            migrationBuilder.CreateIndex(
                name: "IX_SmartPhones_Processor_Id",
                table: "SmartPhones",
                column: "Processor_Id");

            migrationBuilder.CreateIndex(
                name: "IX_SmartPhones_Screen_Id",
                table: "SmartPhones",
                column: "Screen_Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SmartPhones");

            migrationBuilder.DropTable(
                name: "Batteries");

            migrationBuilder.DropTable(
                name: "Cameras");

            migrationBuilder.DropTable(
                name: "Processors");

            migrationBuilder.DropTable(
                name: "Screens");
        }
    }
}
