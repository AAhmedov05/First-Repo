﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.Model.Data
{
    public class Battery
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Battery_Type { get; set; }
        public int Battery_Capacity { get; set; }
    }
}
