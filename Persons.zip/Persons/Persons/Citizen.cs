﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persons
{
    class Citizen:IPerson,IIdentifable,IBirthable
    {
        public string Name { get; private set; }
        public int Age { get; private set; }
        public string Id { get; set; }
        public string BirthDate { get; set; }

        public Citizen(string name, int age) 
        {
            this.Name = name;
            this.Age = age;
        
        }
        public Citizen(string id, string birthDate, string name, int age)
        {

            this.Id = id;
            this.BirthDate = birthDate;
            this.Name = name;
            this.Age = age;
        }
    
    }
}
