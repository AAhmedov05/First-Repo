﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Домашно_26._09._2021
{
    class Program
    {
        static void Main(string[] args)
        {
            string two = Console.ReadLine();
            string sixteen = Console.ReadLine();
            int twoToten = Convert.ToInt32(two,2);
            int sixteenToten = Convert.ToInt32(sixteen,16);
            int result = twoToten + sixteenToten;
            Console.WriteLine("{0} + {1}={2}",twoToten,sixteenToten,result);
        }
    }
}
