﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methodi
{
    class Program
    {
        public static void Swap<T>(T[] elements,int first, int second) 
        {
            T temp = elements[first];
            elements[first] = elements[second];
            elements[second] = temp;

        }

        public static bool IsLess(IComparable first, IComparable second) 
        {
            return first.CompareTo(second) > 0;
        }

        public static void Bubble<T>(T[] elements) where T : IComparable 
        {
            for (int i = 0; i < elements.Length; i++)
            {
                for (int j = 0; j < elements.Length; j++)
                {
                    if (IsLess(elements[i],elements[j]))
                    {
                        Swap(elements,i,j);
                    }
                }
            }
        } 
        static void Main(string[] args)
        {
            string[] names = Console.ReadLine().Split(' ').ToArray();
            Bubble(names);
            foreach (var item in names) 
            {
                Console.Write("{0} ",item);
            }

        }
    }
}
