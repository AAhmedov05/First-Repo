﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelectionSort
{
    class Program
    {
        public static void Swap<T>(T[] elements, int first, int second)
        {
            T temp = elements[first];
            elements[first] = elements[second];
            elements[second] = temp;

        }

        public static bool IsLess(IComparable first, IComparable second)
        {
            return first.CompareTo(second) < 0;
        }

        public static void Selection<T>(T[] elements) where T : IComparable 
        {
            for (int i = 0; i < elements.Length; i++)
            {
                int min = i;
                for (int j = i+1; j < elements.Length; j++)
                {
                    if (IsLess(elements[j],elements[min]))
                    {
                        min = j;
                    }
                }
                Swap(elements,i,min);
            }
        
        }
        static void Main(string[] args)
        {
            string[] names = Console.ReadLine().Split(' ').ToArray();
            Selection(names);
            foreach (var item in names)
            {
                Console.Write("{0} ", item);
            }
        }
    }
}
