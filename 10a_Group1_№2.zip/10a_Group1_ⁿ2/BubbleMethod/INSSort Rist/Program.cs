﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INSSort_Rist
{
    class Program
    {
        private static List<double> InsSort(List<double> list) 
        {
            for (int i = 0; i < list.Count; i++)
            {
                double value = list[i];
                int index = i;
                while (index>0 && list[index-1]<=value)
                {
                    list[index] = list[index-1];
                    index--;
                }
                list[index] = value;
            }
            return list;
        }
        static void Main(string[] args)
        {
            List<double> rist = Console.ReadLine().Split(' ').Select(double.Parse).ToList();
            List<double> insS = new List<double>();
            insS = InsSort(rist);
            for (int i = 0; i < rist.Count; i++)
            {
                Console.WriteLine("{0:f2}",insS[i]);
            }
            Console.WriteLine("Koi NO iskate da proverite?:");
            int first = int.Parse(Console.ReadLine());
            int second = int.Parse(Console.ReadLine());
            Console.WriteLine("NO{0} e visok {1:f2}",first,rist[first-1]);
            Console.WriteLine("NO{0} e visok {1:f2}", second, rist[second - 1]);




        }
    }
}
