﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BubbleMethod
{
    class Program
    {
        private static List<int> BubbleSort(List<int>list) 
        {
            bool swap = true;
            int temp;

            while (swap) 
            {
                swap = false;
                for (int i = 0; i < list.Count-1; i++)
                {
                    if (list[i]<list[i+1])
                    {
                        temp = list[i];
                        list[i] = list[i+1];
                        list[i + 1] = temp;
                        swap = true;
                        
                    }
                }
            }
            return list;
        }
        static void Main(string[] args)
        {

            Console.WriteLine("Vivedete tochkite na uchenicite:");
            List<int> points = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            List<int> bubble = new List<int>();
            bubble = BubbleSort(points);
            
            Console.WriteLine(String.Join(" ",bubble));
            
            Console.WriteLine("Klasirani uchenici:");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(bubble[i]);
            }
            
            Console.WriteLine("Rezervni uchenici:");
            for (int i = 10; i < points.Count; i++)
            {
                Console.WriteLine(bubble[i]);
            }
        }
    }
}
