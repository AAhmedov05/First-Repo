﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visochina
{
    class Program
    {

        private static void Swap(List<double> list, int index, int max)
        {
            double temp = list[index];
            list[index] = list[max];
            list[max] = temp;
        }
        static void Main(string[] args)
        {
            List<double> rist = Console.ReadLine().Split(' ').Select(double.Parse).ToList();
            
            for (int i = 0; i < rist.Count; i++)
            {
                int max = i;
                for (int current = i + 1; current < rist.Count; current++)
                {
                    if (rist[current] > rist[max])
                    {
                        max = current;
                    }
                }

                Swap(rist, i, max);
            }
            
            for (int i = 0; i < rist.Count; i++)
            {
                Console.Write("{0:f2} ",rist[i]);
            }
            Console.WriteLine("Koi nomera iskate da proverite?:");
            int first = int.Parse(Console.ReadLine());
            int second = int.Parse(Console.ReadLine());
            Console.WriteLine("NO:{0} e visok {1:f2}",first,rist[first-1]);
            Console.WriteLine("NO:{0} e visok {1:f2}",second,rist[second-1]);

        }
    }
}
