﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha_s_rekursivna_implementacia_na_dvoichno_tirsene
{
    class Program
    {
        public static int BinarySearch(int[] arr, int key, int start, int end) 
        {
            if (end < start)
            {
                return -1;
            }
            else 
            {
                int mid = (start+end) / 2;
                if (arr[mid] > key)
                {
                    return BinarySearch(arr, key, start, mid - 1);
                }
                else if (arr[mid] < key)
                {
                    return BinarySearch(arr, key, mid + 1, end);
                }
                else 
                {
                    return mid;
                }
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Vivedete nomerata na uchenicite ot tozi klas:");
            int[] students = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            students = students.OrderBy(item => item).ToArray();
            Console.WriteLine(String.Join(" ",students));
            Console.WriteLine("Vivedete nomera na uchenika koyto tirsite:");
            int student = int.Parse(Console.ReadLine());
            if (BinarySearch(students, student, 0, students.Length - 1) == -1)
            {
                Console.WriteLine($"Uchenik s nomer({student}) ne e nameren!!!");
            }
            else
            {
                Console.WriteLine($"Uchenikat e ot tozi klas i se namira na {BinarySearch(students, student, 0, students.Length - 1)+1} poziciq!!!");
            }

        }
    }
}
