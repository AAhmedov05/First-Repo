﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterpolationSearch
{
    class Program
    {
        public static int Interpolation(int[] sortedArr, int key) 
        {
            int low = 0;
            int high = sortedArr.Length - 1;
            while (sortedArr[low] <= key && sortedArr[high] >= key)
            {
                int mid = low + ((key - sortedArr[low]) * (high - low)) / (sortedArr[high] - sortedArr[low]);
                if (sortedArr[mid] < key)
                {
                    low = mid + 1;
                }
                else if (sortedArr[mid] > key)
                {
                    high = mid - 1;
                }
                else
                {
                    return mid;
                }
            }
                if (sortedArr[low]==key)
                {
                    return low;
                }
            return -1;
        } 
         
        static void Main(string[] args)
        {
            Console.WriteLine("Vivedete rista na uchenicite ot tozi klas:");
            int[] students = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            students = students.OrderBy(item => item).ToArray();
            Console.WriteLine(String.Join(" ", students));
            Console.WriteLine("Vivedete rista koyto tirsite:");
            int student = int.Parse(Console.ReadLine());
            if (Interpolation(students, student) == -1)
            {
                Console.WriteLine($"Uchenik s rist({student}) ne e nameren!!!");
            }
            else
            {
                Console.WriteLine($"Uchenikat s tozi rist se namira na {Interpolation(students, student) + 1} poziciq!!!");
            }


        }
    }
}
