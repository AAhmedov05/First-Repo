﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TochkinaUchenici
{
    class Program
    {

        private static void Swap(List<int> list, int index, int max) 
        {
            int temp = list[index];
            list[index] = list[max];
            list[max] = temp;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Vivedete tochkite:");
            List<int> points = Console.ReadLine().Split(' ').Select(int.Parse).ToList();

            for (int i = 0; i < points.Count; i++)
            {
                int max = i;
                for (int current =i+1 ; current <points.Count; current++)
                {
                    if (points[current]>points[max])
                    {
                        max = current;
                    }
                }

                Swap(points, i, max);
            }
            Console.WriteLine(String.Join(" ",points));
            Console.WriteLine("Klasirani");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(points[i]);
            }
            Console.WriteLine("Rezervi");
            for (int i = 10; i < points.Count; i++)
            {
                Console.WriteLine(points[i]);
            }


        }
    }
}
