﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linear_exercise
{
    class Program
    {
        public static int Linear<T>(T[] elements, T key)where T:IComparable 
        {
            for (int i = 0; i < elements.Count(); i++)
            {
                if (elements[i].CompareTo(key)==0)
                {
                    return i;
                }
            }
            return -1;
        }
        static void Main(string[] args)
        {
            //Ot tuk s celi chisla!!!
            int[] nums = new int[]{1, 4, 2, 6, 9, 1, 9, 0, 7};
            Console.WriteLine("Vivedete chisloto koeto tirsite:");
            int tNum = int.Parse(Console.ReadLine());
            if (Linear(nums, tNum)>=0)
            {
                Console.WriteLine($"Chisloto se namira na {Linear(nums, tNum) + 1} poziciq");
            }
            else
            {
                Console.WriteLine("Tova chislo ne se sreshta v tazi kolekciq!");
            }
            //Ot tuk zapochva s simvoli!!!
            char[] symbols = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
            Console.WriteLine("Vivedete simvola koyto iskate:");
            char tSym = char.Parse(Console.ReadLine());
            if (Linear(symbols, tSym) >= 0)
            {
                Console.WriteLine($"Simvola se namira na {Linear(symbols, tSym) + 1} poziciq");
            }
            else
            {
                Console.WriteLine("Tozi simvol ne se sreshta v tazi kolekciq!");
            }
        }
    }
}
