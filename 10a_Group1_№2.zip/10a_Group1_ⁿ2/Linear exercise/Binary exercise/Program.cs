﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binary_exercise
{
    class Program
    {
        public static int Binary<T>(T[] elements, T key) where T : IComparable 
        {
            int start = 0, end = elements.Count() - 1;
            while (end>=start)
            {
                int mid = (start + end) / 2;
                if (elements[mid].CompareTo(key) > 0)
                {
                    end = mid - 1;
                }
                else if (elements[mid].CompareTo(key) < 0)
                {
                    start = mid + 1;
                }
                else 
                {
                    return mid;
                }
            }
            return -1;
        }
        static void Main(string[] args)
        {
            //Ot tuk s celi chisla!!!
            int[] nums = new int[] { 2, 6, 3, 8, 0, 12, 10, 120, 17 };
            nums = nums.OrderBy(item=>item).ToArray();
            Console.WriteLine("Vivedete chisloto koeto tirsite:");
            int tNum = int.Parse(Console.ReadLine());
            if (Binary(nums, tNum) >= 0)
            {
                Console.WriteLine($"Chisloto se namira na {Binary(nums, tNum) + 1} poziciq");
            }
            else
            {
                Console.WriteLine("Tova chislo ne se sreshta v tazi kolekciq!");
            }
            //Ot tuk zapochva s simvoli!!!
            char[] symbols = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
            symbols = symbols.OrderBy(item=>item).ToArray();
            Console.WriteLine("Vivedete simvola koyto iskate:");
            char tSym = char.Parse(Console.ReadLine());
            if (Binary(symbols, tSym) >= 0)
            {
                Console.WriteLine($"Simvola se namira na {Binary(symbols, tSym) + 1} poziciq");
            }
            else
            {
                Console.WriteLine("Tozi simvol ne se sreshta v tazi kolekciq!");
            }
        }
    }
}
