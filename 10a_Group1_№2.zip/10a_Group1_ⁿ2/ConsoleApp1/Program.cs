﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadacha1
{
    class Program
    {
        private static void Swap(List<int> list, int index, int min) 
        {
            int temp = list[index];
            list[index] = list[min];
            list[min] = temp;
        }
        static void Main(string[] args)
        {
            List<int> list =Console.ReadLine().Split(' ').Select(int.Parse).ToList();
             
            for (int index = 0; index < list.Count; index++)
            {
                int min = index; 
                for (int current = index+1; current < list.Count; current++)
                {
                    if (list[current] >list[min])
                    {
                        min = current;
                    }
                }
                Swap(list, index, min);
                Console.WriteLine(string.Join(" ", list));

            }
            Console.WriteLine(string.Join(" ",list));

        }
    }
}
