﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyPhoneProject.Model.Data
{
    public class SmartPhone
    {
        [Key]
        public int Id { get; set; }        
        [Required]
        [StringLength(25)]
        public string Brand_Name { get; set; }
        [StringLength(25)]
        public string Model { get; set; }
        [StringLength(25)]
        public string Operation_System { get; set; }

        [ForeignKey(nameof(Processor))]
        public int Processor_Id { get; set; }
        public Processor Processor { get; set; }

        [ForeignKey(nameof(Battery))]
        public int Battery_Id { get; set; }
        public Battery Battery { get; set; }

        [ForeignKey(nameof(Camera))]
        public int Camera_Id { get; set; }
        public Camera Camera { get; set; }

        [ForeignKey(nameof(Screen))]
        public int Screen_Id { get; set; }
        public Screen Screen { get; set; }
        public DateTime? Release_Date { get; set; }
        public char Imei { get; set; }
        public byte[] Picture { get; set; }
    }
}
