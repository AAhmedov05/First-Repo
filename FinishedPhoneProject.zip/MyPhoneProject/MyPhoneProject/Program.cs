﻿using MyPhoneProject.View;
using System;

namespace MyPhoneProject
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"{new string('-', 14)}Hello USER!!{new string('-', 14)}");
            Display display = new Display();
        }
    }
}
