﻿using MyPhoneProject.Controller;
using MyPhoneProject.Interfaces;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.View.Display_s_methods
{
    public class Processor_s_methods : IMethods
    {
        private PhoneController controller;
        private int choice;
        public void Add()
        {
            controller = new PhoneController();
            Processor processor = new Processor();

            Console.WriteLine("Write name of processor:");
            processor.Name = Console.ReadLine();

            Console.WriteLine("Write Frequance:");
            processor.Frequance = double.Parse(Console.ReadLine());

            Console.WriteLine("Write Ram:");
            processor.Ram = int.Parse(Console.ReadLine());

            controller.processorController.Add(processor);
        }

        public void Delete()
        {
            controller = new PhoneController();

            Console.WriteLine("Enter Id:");
            int id = int.Parse(Console.ReadLine());
            controller.processorController.Delete(id);
            Console.WriteLine("Done.");
        }

        public void SeeAll()
        {
            controller = new PhoneController();

            Console.WriteLine(new string('-', 40));
            var products = controller.processorController.GetAll();
            Console.WriteLine($"{"Id",-1} {"Name",4} {"Frequance",11} {"RAM",-5}");
            foreach (var item in products)
            {
                Console.WriteLine($"{item.Id,-2} {item.Name,5} {item.Frequance,-5} {item.Ram,5}");
            }
            Console.WriteLine(new string('-', 40));
        }
        public void UpdateMenu()
        {
            Console.WriteLine($"{new string('-', 40)}");
            Console.WriteLine("1. Update ALL");
            Console.WriteLine("2. Update name of processor");
            Console.WriteLine("3. Update Frequance");
            Console.WriteLine("4. Update Ram");
            Console.WriteLine("5. Cancel update");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("Enter the action:");
        }

        public void Update()
        {
            controller = new PhoneController();

            SeeAll();
            Console.WriteLine("Enter ID:");
            int id = int.Parse(Console.ReadLine());
            Processor processor = controller.processorController.GetId(id);
            if (processor != null)
            {
                UpdateMenu();
                choice = int.Parse(Console.ReadLine());
                Console.WriteLine($"{new string('-', 40)}");

                switch (choice)
                {
                    case 1: Console.WriteLine("Write name of processor:");
                        processor.Name = Console.ReadLine();

                        Console.WriteLine("Write Frequance:");
                        processor.Frequance = double.Parse(Console.ReadLine());

                        Console.WriteLine("Write Ram:");
                        processor.Ram = int.Parse(Console.ReadLine());

                        controller.processorController.Update(processor);break;
                    case 2:
                        Console.WriteLine("Write new name of processor:");
                        processor.Name = Console.ReadLine(); 
                        
                        controller.processorController.Update(processor); break;

                    case 3:
                        Console.WriteLine("Write new Frequance:");
                        processor.Frequance = double.Parse(Console.ReadLine());
                        
                        controller.processorController.Update(processor); break;

                    case 4:
                        Console.WriteLine("Write new Ram:");
                        processor.Ram = int.Parse(Console.ReadLine());

                        controller.processorController.Update(processor); break;
                    case 5: Console.WriteLine("Update was canceled!!!"); break;
                    default:
                        Console.WriteLine("Invalid action");
                        break;
                }                
            }
            else
            {
                Console.WriteLine("Processor is not available!!!");
            }
        }
    }
}
