﻿using MyPhoneProject.Controller;
using MyPhoneProject.Interfaces;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.View.Display_s_methods
{
    public class Battery_s_methods : IMethods
    {
        private PhoneController controller;
        private int choice;
        public void Add()
        {
            Battery battery = new Battery();
            controller = new PhoneController();

            Console.WriteLine("Write battery type:");
            battery.Battery_Type = Console.ReadLine();

            Console.WriteLine("Write battery capacity:");
            battery.Battery_Capacity = int.Parse(Console.ReadLine());

            controller.batteryController.Add(battery);
        }

        public void Delete()
        {
            controller = new PhoneController();

            Console.WriteLine("Enter Id:");
            int id = int.Parse(Console.ReadLine());
            controller.batteryController.Delete(id);
            Console.WriteLine("Done.");
        }

        public void SeeAll()
        {
            controller = new PhoneController();
            Console.WriteLine(new string('-',40));
            var products = controller.batteryController.GetAll();
            Console.WriteLine($"{"Id",-2} {"Battery_Type",-10} {"Battery_Capacity",-5}");
            foreach (var item in products)
            {
                Console.WriteLine($"{item.Id,-2} {item.Battery_Type,-10} {item.Battery_Capacity,6}");
            }
            Console.WriteLine(new string('-', 40));

        }

        public void UpdateMenu()
        {
            Console.WriteLine($"{new string('-', 40)}");
            Console.WriteLine("1. Update all");
            Console.WriteLine("2. Update battery capacity");
            Console.WriteLine("3. Update battery type");
            Console.WriteLine("4. Cancel update");
            Console.WriteLine(new string('-',40));
            Console.WriteLine("Enter the action:");
        }

        public void Update()
        {
            controller = new PhoneController();
            
            SeeAll();
            Console.WriteLine("Enter ID:");
            int id = int.Parse(Console.ReadLine());
            Battery battery = controller.batteryController.GetId(id);

            if (battery != null)
            {
                UpdateMenu();
                choice = int.Parse(Console.ReadLine());
                Console.WriteLine($"{new string('-', 40)}");

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Write battery type:");
                        battery.Battery_Type = Console.ReadLine();

                        Console.WriteLine("Write battery capacity:");
                        battery.Battery_Capacity = int.Parse(Console.ReadLine());

                        controller.batteryController.Update(battery);
                        break;
                    case 2:
                        Console.WriteLine("Write new battery type:");
                        battery.Battery_Type = Console.ReadLine();
                        controller.batteryController.Update(battery);

                        break;
                    case 3:
                        Console.WriteLine("Write battery capacity:");
                        battery.Battery_Capacity = int.Parse(Console.ReadLine());
                        controller.batteryController.Update(battery);

                        break;
                    case 4: Console.WriteLine("Update was canceled");break;
                    default:
                        Console.WriteLine("Invalid action");
                        break;
                }
                
            }
            else
            {
                Console.WriteLine("Battery is not available!!!");
            }
        }
    }
}
