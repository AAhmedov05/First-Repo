﻿using MyPhoneProject.Controller;
using MyPhoneProject.Model;
using MyPhoneProject.Model.Data;
using MyPhoneProject.View.Display_s_methods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.View
{
    public class Display
    {

        public SmartPhone_s_methods smartPhone = new SmartPhone_s_methods();
        public Processor_s_methods processor = new Processor_s_methods();
        public Battery_s_methods battery = new Battery_s_methods();
        public Screen_s_methods screen = new Screen_s_methods();
        public Camera_s_methods camera = new Camera_s_methods();

        private int exit=0;
        private int leave=6;
        
        private void ShowMenu() 
        {
            Console.WriteLine(new string('*', 40));
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Update");
            Console.WriteLine("3. Delete");
            Console.WriteLine("4. SeeAll");
            Console.WriteLine("6. Leave");
        }
        private void ShowTables()
        {
            Console.WriteLine(new string('*', 40));
            Console.WriteLine($"{new string('*', 10)}YOU ARE IN THE MENU!{new string('*', 10)}");
            Console.WriteLine(new string('*', 40));
            Console.WriteLine("1. SmartPhone");
            Console.WriteLine("2. Processor");
            Console.WriteLine("3. Battery");
            Console.WriteLine("4. Screen");
            Console.WriteLine("5. Camera");
            Console.WriteLine("0. Exit");
        }
        private void MainMenu() 
        {
            int command = -1;
            //int updateCommand = -1;
            do 
            {
                ShowTables();
                Console.Write("Enter the table number:");
                command= int.Parse(Console.ReadLine());
                switch (command)
                {
                    case 1:
                        Console.WriteLine(new string('*', 40));
                        Console.WriteLine("You are in the SmartPhone!!!");

                        while (command != leave)
                        {
                            ShowMenu();
                            Console.Write("Which action you want for SmartPhone:");
                            command = int.Parse(Console.ReadLine());
                            switch (command)
                            {
                                case 1:
                                    smartPhone.Add();
                                    break;
                                case 2:
                                    smartPhone.Update();
                                    Console.WriteLine(new string('-', 80));
                                    Console.WriteLine($"{new string('#', 33)}UPDATED TABLE!{new string('#', 33)}");
                                    smartPhone.SeeAll();
                                    break;
                                case 3:
                                    smartPhone.Delete();
                                    break;
                                case 4:
                                    smartPhone.SeeAll();
                                    break;
                                default:
                                    break;
                            }
                            
                        }
                        break;
                    case 2:
                        Console.WriteLine(new string('*', 40));
                        Console.WriteLine("You are in the Processor!!!");

                        while (command != leave)
                        {
                            ShowMenu();
                            Console.Write("Which action you want for Processor:");
                            command = int.Parse(Console.ReadLine());

                            switch (command)
                            {
                                case 1:
                                    processor.Add();
                                    break;
                                case 2:
                                    processor.Update();
                                    Console.WriteLine(new string('-', 80));
                                    Console.WriteLine($"{new string('#', 33)}UPDATED TABLE!{new string('#', 33)}");
                                    processor.SeeAll();
                                    break;
                                case 3:
                                    processor.Delete();
                                    break;
                                case 4:
                                    processor.SeeAll();
                                    break;
                                default:
                                    break;
                            }
                        } 
                        break;

                    case 3:
                        Console.WriteLine(new string('*', 40));
                        Console.WriteLine("You are in the Battery!!!");
                        
                        while (command != leave)
                        {
                            ShowMenu();
                            Console.Write("Which action you want for Battery:");
                            command = int.Parse(Console.ReadLine());

                            switch (command)
                            {
                                case 1:
                                    battery.Add();
                                    break;
                                case 2:
                                    battery.Update();
                                    Console.WriteLine(new string('-', 80));
                                    Console.WriteLine($"{new string('#', 33)}UPDATED TABLE!{new string('#', 33)}");
                                    battery.SeeAll();
                                    break;
                                case 3:
                                    battery.Delete();
                                    break;
                                case 4:
                                    battery.SeeAll();
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine(new string('*', 40));
                        Console.WriteLine("You are in the Screen!!!");
                        
                        while (command != leave)
                        {
                            ShowMenu();
                            Console.Write("Which action you want for Screen:");
                            command = int.Parse(Console.ReadLine());

                            switch (command)
                            {
                                case 1:
                                    screen.Add();
                                    break;
                                case 2:
                                    screen.Update();
                                    Console.WriteLine(new string('-', 80));
                                    Console.WriteLine($"{new string('#', 33)}UPDATED TABLE!{new string('#', 33)}");
                                    screen.SeeAll();
                                    break;
                                case 3:
                                    screen.Delete();
                                    break;
                                case 4:
                                    screen.SeeAll();
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;

                    case 5:
                        Console.WriteLine(new string('*', 40));
                        Console.WriteLine("You are in the Camera!!!");
                        
                        while (command != leave)
                        {
                            ShowMenu();
                            Console.Write("Which action you want for Camera:");
                            command = int.Parse(Console.ReadLine());

                            switch (command)
                            {
                                case 1:
                                    camera.Add();
                                    break;
                                case 2:
                                    camera.Update();
                                    Console.WriteLine(new string('-',80));
                                    Console.WriteLine($"{new string('#', 33)}UPDATED TABLE!{new string('#', 33)}");
                                    camera.SeeAll();
                                    break;
                                case 3:
                                    camera.Delete();
                                    break;
                                case 4:
                                    camera.SeeAll();
                                    break;
                                default:
                                    break;
                            }
                        }
                            break;
                        
                    default:
                        break;
                }

            } while (exit!=command);
        }

        public Display()
        {
            MainMenu();
        }
    }
}
