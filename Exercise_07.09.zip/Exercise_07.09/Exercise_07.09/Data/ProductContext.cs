﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exercise_07._09.Data.Model;

namespace Exercise_07._09.Data
{
    public class ProductContext:DbContext
    {
        public ProductContext()
        {
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) 
        {
            var connString = "Data Source=(localdb)\\MSSQLLocalDB;" +
                "Initial Catalog=ShopDB;" +
                "Integrated Security=True;";
            optionsBuilder.UseSqlServer(connString);
        }
        public DbSet<Product> Products { get; set; }
    }
}
