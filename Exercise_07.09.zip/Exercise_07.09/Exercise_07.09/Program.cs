﻿using Exercise_07._09.Presentation;
using System;

namespace Exercise_07._09
{
    public class Program
    {
        static void Main(string[] args)
        {
            Display display = new Display();
        }
    }
}
