﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace PodgotovkaZaKontrolno_24._02._2023
{
    public class AnimalCmparator : IComparer<Animal>
    {
        public int Compare(Animal x, Animal y)
        {
            var compare = x.Name.CompareTo(y.Name);
            if (compare==0)
            {
                return y.Age.CompareTo(x.Age);
            }
            else
            {
                return compare;
            }
            
        }
    }
}
