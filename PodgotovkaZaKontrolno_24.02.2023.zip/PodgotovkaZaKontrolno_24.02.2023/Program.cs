﻿using System;
using System.Collections.Generic;

namespace PodgotovkaZaKontrolno_24._02._2023
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal animalOne = new Animal("Charly", 5, "Maks");
            Animal animalTwo = new Animal("Leon", 4, "Surga", "Manu");
            Animal animalThree = new Animal("Oto", 9);
            Animal animalFoor = new Animal("Kari", 5, "Maksim");
            Animal animalFive = new Animal("Kara", 4, "Scharo", "Sara");

            ZooPark zooparkOne = new ZooPark();
            ZooPark zooparkTwo = new ZooPark(animalOne, animalTwo, animalThree, animalFoor, animalFive);
            foreach (var anim in zooparkTwo)
            {
                Console.WriteLine(anim.Name + " " + anim.Age);
            }

            Console.WriteLine($"{new string('-', 20)}Comparable AREA{new string('-', 20)}");
            List<Animal> animalsForSort = new List<Animal>()
            {
                animalOne,animalTwo,animalThree,animalFoor,animalFive
            };

            animalsForSort.Sort();

            foreach (var item in animalsForSort)
            {
                Console.WriteLine(item.ToString());
            }

            Console.WriteLine($"{new string('-', 20)}Comparer AREA{new string('-', 20)}");

            AnimalCmparator animalComparator = new AnimalCmparator();
            List<Animal> animalsForSortComparer = new List<Animal>()
            {
                animalOne,animalTwo,animalThree,animalFoor,animalFive
            };

            animalsForSortComparer.Sort(animalComparator.Compare);

            foreach (var item in animalsForSortComparer)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
