﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace PodgotovkaZaKontrolno_24._02._2023
{
    public class ZooPark:IEnumerable<Animal>
    {
        private List<Animal> animals;

        public ZooPark(params Animal[]animals)
        {
            this.animals = new List<Animal>(animals);
        }

        public IEnumerator<Animal> GetEnumerator()
        {
            for (int i = 0; i < animals.Count; i++)
            {
                yield return animals[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
