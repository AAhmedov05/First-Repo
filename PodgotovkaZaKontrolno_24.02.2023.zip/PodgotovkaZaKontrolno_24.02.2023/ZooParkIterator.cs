﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace PodgotovkaZaKontrolno_24._02._2023
{
    public class ZooParkIterator : IEnumerator<Animal>
    {
        private List<Animal> animals;
        private int index;
        public Animal Current => animals[index];

        object IEnumerator.Current => Current;

        public void Dispose()
        {
           
        }

        public bool MoveNext()
        {
            index++;
            return index < animals.Count;
        }

        public void Reset()
        {
            index = -1;
        }
    }
}
