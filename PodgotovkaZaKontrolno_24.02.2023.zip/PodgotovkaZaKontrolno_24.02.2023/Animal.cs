﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace PodgotovkaZaKontrolno_24._02._2023
{
    public class Animal:IComparable<Animal>
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public List<string> Children { get; set; }

        public Animal(string name, int age, params string[] child)
        {
            this.Name = name;
            this.Age = age;
            Children = new List<string>(child);
        }

        public int CompareTo(Animal other)
        { 
            var compare = other.Age.CompareTo(this.Age);
            if (compare==0)
            {
                return this.Name.CompareTo(other.Name);
            }
            return compare;
        }

        public override string ToString()
        {
            return $"{this.Name}-{this.Age}";
        }
    }
}
