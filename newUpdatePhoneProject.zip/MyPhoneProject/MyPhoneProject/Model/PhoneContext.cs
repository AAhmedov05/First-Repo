﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MyPhoneProject.Model.Data;

namespace MyPhoneProject.Model
{
    public class PhoneContext:DbContext
    {
        //public PhoneContext()
        //{
        //    //Here we check database
        //    Database.EnsureCreated();
        //}

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) 
        {
            string conn = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Phones;Integrated Security=True;";
            optionsBuilder.UseSqlServer(conn);
        }

        public DbSet<SmartPhone> SmartPhones { get; set; }
        public DbSet<Processor> Processors { get; set; }
        public DbSet<Battery> Batteries { get; set; }
        public DbSet<Camera> Cameras { get; set; }
        public DbSet<Screen> Screens { get; set; }
    }
}
