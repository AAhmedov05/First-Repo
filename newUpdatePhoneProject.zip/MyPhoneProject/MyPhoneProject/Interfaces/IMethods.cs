﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.Interfaces
{
    interface IMethods
    {
        public void Add();
        public void Update();
        public void Delete();
        public void SeeAll();
    }
}
