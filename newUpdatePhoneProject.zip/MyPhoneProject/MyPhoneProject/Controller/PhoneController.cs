﻿using MyPhoneProject.Controller.Entities_controller_s;
using MyPhoneProject.Model;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.Controller
{
    public class PhoneController
    {
        public SmartPhoneController smartPhoneController = new SmartPhoneController();
        public ProcessorController processorController = new ProcessorController();
        public BatteryController batteryController = new BatteryController();
        public ScreenController screenController = new ScreenController();
        public CameraController cameraController = new CameraController();
    }
}
