﻿using MyPhoneProject.Interfaces;
using MyPhoneProject.Model;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.Controller.Entities_controller_s
{
    public class BatteryController:ICRUD<Battery>
    {
        private PhoneContext context;

        public void Add(Battery item)
        {
            using (context = new PhoneContext())
            {
                context.Batteries.Add(item);
                context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            using (context = new PhoneContext())
            {
                var battery = context.Batteries.Find(id);
                if (battery != null)
                {
                    context.Batteries.Remove(battery);
                    context.SaveChanges();
                }
            }
        }

        public List<Battery> GetAll()
        {
            using (context = new PhoneContext())
            {
                return context.Batteries.ToList();
            }
        }

        public Battery GetId(int id)
        {
            using (context=new PhoneContext())
            {
                return context.Batteries.Find(id);
            }
        }

        public void Update(Battery item)
        {
            using (context = new PhoneContext())
            {
                var battery = context.Batteries.Find(item.Id);
                if (battery != null)
                {
                    context.Entry(battery).CurrentValues.SetValues(item);
                    context.SaveChanges();
                }
            }
        }
    }
}
