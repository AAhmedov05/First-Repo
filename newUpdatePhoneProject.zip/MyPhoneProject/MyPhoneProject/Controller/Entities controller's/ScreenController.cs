﻿using MyPhoneProject.Interfaces;
using MyPhoneProject.Model;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.Controller.Entities_controller_s
{
    public class ScreenController:ICRUD<Screen>
    {
        private PhoneContext context;

        public void Add(Screen item)
        {
            using (context = new PhoneContext())
            {
                context.Screens.Add(item);
                context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            using (context = new PhoneContext())
            {
                var screen = context.Screens.Find(id);
                if (screen != null)
                {
                    context.Screens.Remove(screen);
                    context.SaveChanges();
                }
            }
        }

        public List<Screen> GetAll()
        {
            using (context = new PhoneContext())
            {
                return context.Screens.ToList();
            }
        }

        public Screen GetId(int id)
        {
            using (context = new PhoneContext())
            {
                return context.Screens.Find(id);
            }
        }

        public void Update(Screen item)
        {
            using (context = new PhoneContext())
            {
                var screen = context.Screens.Find(item.Id);
                if (screen != null)
                {
                    context.Entry(screen).CurrentValues.SetValues(item);
                    context.SaveChanges();
                }
            }
        }
    }
}
