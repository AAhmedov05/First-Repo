﻿using MyPhoneProject.Interfaces;
using MyPhoneProject.Model;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.Controller.Entities_controller_s
{
    public class ProcessorController : ICRUD<Processor>
    {
        private PhoneContext context;
        public void Add(Processor item)
        {
            using (context = new PhoneContext())
            {
                context.Processors.Add(item);
                context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            using (context = new PhoneContext())
            {
                var processor = context.Processors.Find(id);
                if (processor != null)
                {
                    context.Processors.Remove(processor);
                    context.SaveChanges();
                }
            }
        }

        public List<Processor> GetAll()
        {
            using (context = new PhoneContext())
            {
                return context.Processors.ToList();
            }
        }

        public Processor GetId(int id)
        {
            using (context = new PhoneContext())
            {
                return context.Processors.Find(id);
            }
        }

        public void Update(Processor item)
        {
            using (context = new PhoneContext())
            {
                var processor = context.Processors.Find(item.Id);
                if (item != null)
                {
                    context.Entry(processor).CurrentValues.SetValues(item);
                    context.SaveChanges();
                }
            }
        }
    }
}
