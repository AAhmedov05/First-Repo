﻿using MyPhoneProject.Controller;
using MyPhoneProject.Interfaces;
using MyPhoneProject.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneProject.View.Display_s_methods
{
    public class Camera_s_methods : IMethods
    {
        private PhoneController controller;
        public void Add()
        {
            Camera camera = new Camera();
            controller = new PhoneController();

            Console.WriteLine("Write front camera:");
            camera.Front_Camera = int.Parse(Console.ReadLine());

            Console.WriteLine("Write raer camera:");
            camera.Rear_Camera = int.Parse(Console.ReadLine());

            controller.cameraController.Add(camera);
        }

        public void Delete()
        {
            controller = new PhoneController();

            Console.WriteLine("Enter Id:");
            int id = int.Parse(Console.ReadLine());
            controller.cameraController.Delete(id);
            Console.WriteLine("Done.");
        }

        public void SeeAll()
        {
            controller = new PhoneController();

            Console.WriteLine(new string('-', 40));
            var products = controller.cameraController.GetAll();
            Console.WriteLine($"{"Id",-2} {"Front_Camera",-5} {"Rear_Camera",-5}");
            foreach (var item in products)
            {
                Console.WriteLine($"{item.Id,-2} {item.Front_Camera,-5} {item.Rear_Camera,9}");
            }
            Console.WriteLine(new string('-', 40));

        }

        public void Update()
        {
            controller = new PhoneController();

            Console.WriteLine("Enter ID:");
            int id = int.Parse(Console.ReadLine());
            Camera camera = controller.cameraController.GetId(id);

            if (camera != null)
            {
                controller = new PhoneController();

                Console.WriteLine("Write front camera:");
                camera.Front_Camera = int.Parse(Console.ReadLine());

                Console.WriteLine("Write raer camera:");
                camera.Rear_Camera = int.Parse(Console.ReadLine());

                controller.cameraController.Update(camera);
            }
            else
            {
                Console.WriteLine("Camera is not available!!!");
            }
        }
    }
}
